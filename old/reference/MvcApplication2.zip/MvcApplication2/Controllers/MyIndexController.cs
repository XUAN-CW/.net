﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcApplication2.Models;
namespace MvcApplication2.Controllers
{
    public class MyIndexController : Controller
    {
        //
        // GET: /MyIndex/
        mydbDataContext mycontext=new mydbDataContext();
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult doget()
        {
            ViewData["output"] = Request["name"].ToString();
            return View();
        }
        public ActionResult remove()
        {
            int id = Convert.ToInt32(Request["id"].ToString());
            Goods dlins = mycontext.Goods.Where(o => o.id == id).First();
            mycontext.Goods.DeleteOnSubmit(dlins);
            mycontext.SubmitChanges();
            List<Goods> result = mycontext.Goods.ToList();
            List<String> resulter = new List<string>();
            String s;
            foreach(Goods item in result)
            {
                s = item.id.ToString();
                resulter.Add("id:" + s + '-' + "name:" + item.name + "\n");
            }
            Session["result"] = resulter;
            return View();
        }
        public ActionResult add()
        {
            String name = Request["name1"].ToString();
            Goods delins = new Goods();
            delins.name = name;
            mycontext.Goods.InsertOnSubmit(delins);
            mycontext.SubmitChanges();
            List<Goods> result = mycontext.Goods.ToList();
            List<String> resulter = new List<string>();
            String s;
            foreach (Goods item in result)
            {
                s = item.id.ToString();
                resulter.Add("id:" + s + '-' + "name:" + item.name + "\n");
            }
            Session["result"] = resulter;
            return View();
        }
        public ActionResult eidt()
        {

            int id = Convert.ToInt32(Request["id1"].ToString());
            String name = Request["name2"].ToString();
            Goods dlins = mycontext.Goods.Where(o => o.id == id).First();
            mycontext.Goods.DeleteOnSubmit(dlins);
            dlins.name = name;
            mycontext.Goods.InsertOnSubmit(dlins);
            mycontext.SubmitChanges();
            List<Goods> result = mycontext.Goods.ToList();
            List<String> resulter = new List<string>();
            String s;
            foreach (Goods item in result)
            {
                s = item.id.ToString();
                resulter.Add("id:"+s+'-'+"name:"+item.name+"\n");
            }
            Session["result"] = resulter;
            return View();
        }
        public ActionResult select()
        {
            List<Goods> result = mycontext.Goods.ToList();
            List<String> resulter = new List<string>();
            String s;
            foreach (Goods item in result)
            {
                s = item.id.ToString();
                resulter.Add("id:" + s + '-' + "name:" + item.name + "\n");
            }
            Session["result"] = resulter;
            return View();
        }
        
    }
}
